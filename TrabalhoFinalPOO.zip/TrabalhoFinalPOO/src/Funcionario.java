/** 
 * Implementa a classe Funcionario
 * @author Calvin Suzuki de Camargo, 11232420
 */
public class Funcionario extends Pessoa {
	
	private Double salario;
	private int reclamacoes;
	
	/**
	 * Construtor da classe funcionario
	 * @param register - long - Registro na escola
	 * @param nome - String - Nome da pessoa
	 * @param freq - double - Frequencia da pessoa
	 * @param senha - String - A senha da conta
	 * @param salario - double - Valor do salario
	 * @param reclamacoes - int - Quantidade de reclamacoes
	 */
	Funcionario(long register, String nome, double freq, String senha, double salario, int reclamacoes) {
		super(register, nome, freq, senha);
		this.salario = salario;
		this.reclamacoes = reclamacoes;
	}
	
	/**
	 * @return string com todas as caracter�sticas do funcionario
	 */
	@Override
	public String toString() {
		String str;
		
		str = "Funcionario";
		str += "\nNome: " + getNome();
		str += "\nN� de Registro: " + getRegister();
		str += "\nFrequ�ncia: " + getFreq();
		str += "\nSalario: " + salario;			
		str += "\nReclamacoes: " + reclamacoes;
		
		return str;
	}
	
	/**
	 * @return salario
	 */
	public Double getSalario() {
		return salario;
	}
	
	/**
	 * @return n�mero de reclama��es
	 */
	public int getReclam() {
		return reclamacoes;
	}
	
	/**
	 * @param salario - novo salario
	 */
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	/**
	 * @param reclamacoes - novo n�mero de reclama��es
	 */
	public void setReclam(int reclamacoes) {
		this.reclamacoes = reclamacoes;
	}

}
